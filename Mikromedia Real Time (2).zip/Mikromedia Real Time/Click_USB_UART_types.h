#ifndef _USB_UART_T_
#define _USB_UART_T_

#include "stdint.h"

#ifndef _USB_UART_H_

#define T_USB_UART_P const uint8_t* 

#endif
#endif