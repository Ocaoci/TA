/*int dirac(int x) {
    int diracdelta;
    if (x == 0) {
        diracdelta = 1;
    } else {
        diracdelta = 0;
    }
    return diracdelta;
}*/
void bingkai1(int x, int y, float dat){
   TFT_Set_Pen(CL_BLACK, 1);
   TFT_Set_Brush(1, 0,0, LEFT_TO_RIGHT, CL_BLACK, CL_BLACK);
   TFT_Rectangle(x, y, x+140, y+100);
   TFT_Set_Pen(CL_YELLOW, 5);
   TFT_Set_Font(Tahoma32x33_Bold, CL_WHITE, FO_HORIZONTAL);
   FloatToStr(dat, text );
   TFT_Write_Text(text, x, y);
}


void memsetout(){
    memset(w2fb1, 0, sizeof(w2fb1));
    memset(w2fb2, 0, sizeof(w2fb2));
    memset(w2fb3, 0, sizeof(w2fb3));
    memset(hasil_QRS, 0, sizeof(hasil_QRS));
}
float get_index(float *array, int n) {
    if(n < 0) {
        return array[0];
    }
    return array[n];
}

float get_rotating_index(float *array, int max, int n) {
    if(n < 0) {
        return array[max + n];
    }
    return array[n];
}
void dwtout(){
int x, y;
   /* float gradien1[1250], gradien2[1252], gradien3[1254];
    float  hasil1[1250], hasil2[1250], hasil3[1250], temp[1250];*/
   /*for (j = 1; j<=3; j++){
        for (i = -(dua_pangkat[j]+dua_pangkat[j-1]-2); i <= -(1-dua_pangkat[j-1]); i++){
            if (j == 1){*/
    /*qj1[i+1] = -2.0*(float)(dirac(i)-dirac(i+1))*/;
           /*}  else if (j==2){*/
    /*qj2[i+4] = -1.0/4.0*(float)(dirac(i-1) + 3*dirac(i) + 2*dirac(i+1) - 2*dirac(i+2)- 3*dirac(i+3) - dirac(i+4))*/;
           /*}   else if (j==3){*/
    /*qj3[i+10] = -1.0/32.0*(float)(dirac(i-3) + 3*dirac(i-2) + 6*dirac(i-1) + 10*dirac(i) + 11*dirac(i+1) + 9*dirac(i+2) + 4*dirac(i+3) - 4*dirac(i+4) - 9*dirac(i+5) - 11*dirac(i+6) - 10*dirac(i+7) - 6*dirac(i+8) - 3*dirac(i+9) - dirac(i+10))*/;



    //}

   /*for (i = 0; i <= 1250; i++){*/
  /*w2fb1[i + delay[1]] = 0;
     w2fb2[i + delay[2]] = 0;
     w2fb3[i + delay[3]] = 0;*/


    w2fb1[i] = qj1[0] * sinyal[i] +  qj1[1] * get_index(sinyal, i-1);
    w2fb2[i] = qj2[0] * sinyal[i] +  qj2[1] * get_index(sinyal, i-1) +  qj2[2] * get_index(sinyal, i-2) +  qj2[3] * get_index(sinyal, i-3) +  qj2[4] * get_index(sinyal, i-4) +  qj2[5] * get_index(sinyal, i-5);
    w2fb3[i] = qj3[0] * sinyal[i] +  qj3[1] * get_index(sinyal, i-1) +  qj3[2] * get_index(sinyal, i-2) +  qj3[3] * get_index(sinyal, i-3) +  qj3[4] * get_index(sinyal, i-4) +  qj3[5] * get_index(sinyal, i-5) +  qj3[6] * get_index(sinyal, i-6) +  qj3[7] * get_index(sinyal, i-7) +  qj3[8] * get_index(sinyal, i-8) +  qj3[9] * get_index(sinyal, i-9) +  qj3[10] * get_index(sinyal, i-10) +  qj3[11] * get_index(sinyal, i-11) +  qj3[12] * get_index(sinyal, i-12) +  qj3[13] * get_index(sinyal, i-13);


   /*memset(w2fb1, 0, sizeof(w2fb1));
    memset(w2fb1, 0, sizeof(w2fb2));
    memset(w2fb1, 0, sizeof(w2fb3));*/

    gradien1 = w2fb1[i] - w2fb1[i-1];
    gradien2 = w2fb2[i] - w2fb2[i-2];
    gradien3 = w2fb3[i] - w2fb3[i-3];
    
    if (gradien1 > -4.0 && gradien2 > -3.0 && gradien3 > 2.0){
       hasil_QRS[i] = 1.0;
    } else {
       hasil_QRS[i] = 0.0;
    }
   if (hasil_QRS[i] == 1 && hasil_QRS[i-1] == 0){
//        count_k[k_length]=i;
//  }
//   nilairr[b_lenght]= fabs((count_k[k_lenght]/125) - (count_k[k_lenght-1]/125));
//   bpm[bpm_lenght] = 60/nilairr[b_lenght];
//   b_lenght++;
//   k_lenght++;
//   bpm_lenght++;

     //menentukan nilai RR
   if (hasil_QRS[i] == 1.0 && hasil_QRS[i-1] == 0.0){
        count_k[k_length]=i;

        if (k_length >= 2.0) {
             //  Nilai rrinterval
             nilairr[b_length] =  fabs((count_k[k_length]/125) - (count_k[k_length-1]/125));

             // Nilai BPM
             bpm[c_length] = (float)60.0/nilairr[b_length];


             //Plot Heart Rate
//             if(bpm[c_length] > 45.0){
               bingkai1(390,395,bpm[c_length]);
//             }
//             TFT_Set_Pen(CL_BLACK, 1);
//             TFT_Set_Brush(1, 0,0, LEFT_TO_RIGHT, CL_BLACK, CL_BLACK);
//             TFT_Rectangle(x, y, x+200, y+100);
//             TFT_Set_Pen(CL_YELLOW, 5);
//             TFT_Set_Font(Tahoma32x33_Bold, CL_WHITE, FO_HORIZONTAL);
//             FloatToStr( bpm[c_lenght], text );
//             TFT_Write_Text(text, 390, 395);

//             IntToStr(bpm[c_lenght],text);

//             mikrobus_logWrite(text, _LOG_LINE);
             b_length++;
             c_length++;
        }
        k_length++;

   }
}
}

    
    //free(gradien1);
    //free(gradien2);
    //free(gradien3);
    
    //free(w2fb1);
    //free(w2fb2);
    //free(w2fb3);
    
    
   //  for (i = 0; i <= 1250; i++);{

      //  if(gradien1[n] > 0.3) {
      //       hasil1[n] = 1;
      //  }
      //  else {
      //      hasil1[n] = 0;
      //  }

      //  if(gradien2[n] > 1) {
      //      hasil2[n] = 1;
      //  }
      //  else {
      //      hasil2[n] = 0;
      //  }
      //  if(gradien3[n] > 2) {
      //      hasil3[n] = 1;
      //   }
      //  else {
      //       hasil3[n] = 0;
      //  }
      //  if (hasil1[n] == hasil2[n]){
      //  temp[n]=1;
      //  }
      //  else{temp[n] = 0;}
      //  if (temp[n] == hasil3[n]){
      //  hasil_QRS[n]=1;
      //  }
      //  else{hasil_QRS[n] = 0;}
    // }