const code char Tahoma32x33_Bold[];
const code char Tahoma11x13_Regular[];
const code char ITS1_jpg[3957];
const code char bme_jpg[2876];