void hasilrr(){
     if( hasil_QRS[i] = 1 && hasil_QRS[i-1] = 0){
        count_k[k++]=i;
  }
}