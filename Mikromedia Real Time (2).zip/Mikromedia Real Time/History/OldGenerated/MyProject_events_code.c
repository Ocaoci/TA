#include "MyProject_objects.h"
#include "MyProject_resources.h"

//--------------------- User code ---------------------//

void InitTimer7(){
  RCC_APB1ENR.TIM7EN = 1;
  TIM7_CR1.CEN = 0;
  TIM7_PSC = 11;
  TIM7_ARR = 55999;
  NVIC_IntEnable(IVT_INT_TIM7);
  TIM7_DIER.UIE = 1;
  TIM7_CR1.CEN = 1;
}
void bingkai(int X1, int Y1, int X2, int Y2)
{
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Set_Brush(1, 0, 0, LEFT_TO_RIGHT, CL_WHITE, CL_WHITE);
    TFT_Rectangle(X1, Y1, X2, Y2);
//    TFT_Set_Font(Tahoma11x13_Regular, CL_BLACK, FO_HORIZONTAL);//   FloatToStr(data, text);
//    TFT_Write_Text(text, X1, Y1);
//    Delay_ms(10);
}

void systemInit(){
mikrobus_uartInit(_MIKROBUS2, &_USB_UART_UART_CFG[0] );
mikrobus_logInit( _MIKROBUS2, 115200 );
}

void applicationInit()
{
    /*usb_uart_uartDriverInit( (T_USB_UART_P)&_MIKROBUS2_GPIO, (T_USB_UART_P)&_MIKROBUS2_UART );
    mikrobus_logWrite( "Initialized", _LOG_LINE );*/
    Delay_ms( 100 );
    InitTimer7();
   // ecg_gpioDriverInit( (T_ECG_P)&_MIKROBUS1_GPIO );
    Delay_ms( 200 );
    ADC1_Init();
    ADC_Set_Input_Channel( _ADC_CHANNEL_4 ); //Mikrobus 1
    Delay_ms( 200 );
}

//----------------- End of User code ------------------//

// Event Handlers

void ButtonRound1OnClick() {
     DrawScreen(&Screen2);
/*bingkai(0, 0, 800, 380);*/
}

void Button1OnClick() {
   buttonFlag = ~buttonFlag;
     if(!buttonFlag){
        Button1.Caption = "RUN";
        Button1.Color = CL_RED;
     }
     else{
        Button1.Caption = "STOP";
        Button1.Color = CL_LIME;
        memsetout();
     }
     DrawRoundButton(&Button1);


   /*x = 32;
   y = 40;
   TFT_Set_Pen(CL_WHITE, 2);
   TFT_Set_Brush(0, 0, 0, LEFT_TO_RIGHT, CL_WHITE, CL_WHITE);
   TFT_Rectangle(x, y, 770, 380);
   dwtout();
   for (i = 0; i <= 740; i++) {
       readADC = ADC1_Get_Sample(4);
       signal[i]  = (float) (readADC*3.3)/4095;
       TFT_Set_Pen(CL_RED, 2);
       TFT_Line(32+(i-1), 400-200*signal[i-1], 32+i, 400-200*signal[i]);
       Delay_Us(4000);
   }*/
   /*for (i = 0; i <= 740; i++) {
       TFT_Set_Pen(CL_BLUE, 1);
       TFT_Line(32+(i-1), 230-20*hasil_QRS[i-1], 32+i, 230-20*hasil_QRS[i]);
       TFT_Set_Pen(CL_RED, 2);
       TFT_Line(32+(i-1), 200-20*sinyal[i-1], 32+i, 200-20*sinyal[i]);
       Delay_ms(10);
   }*/

}
void Button2OnClick() {
     DrawScreen(&Screen1);
     //rmssdout();
}
void ApplicationTaskECG() {
     readADC = ADC1_Get_Sample(4);
     i = n%800;
     d = (n-3)%800;
//     n++;
     sinyal[i]  = (float) (readADC*3.3)/4095;
     dwtout();

     if (i == 0) bingkai(0, 0, 800, 380);
       //black vertical line
//     TFT_Set_Pen(CL_BLACK, 1);
//     TFT_V_Line(0,400,5+(i*2));
     TFT_Set_Pen(CL_RED, 2);
     TFT_Line((i)-1, 260-50*sinyal[i-1], i, 260-50*sinyal[i]);

     /*if (i == 0) bingkai(0, 0, 800, 430);*/
     TFT_Set_Pen(CL_WHITE, 2);
     TFT_Line(d-1, 320-50* hasil_QRS[i-1], d, 320-50*hasil_QRS[i]);

//     bingkai1(390,39,bpm[c_lenght]);
//     if (n == 800)
     if( n == 1200){
         n = 0;
         c_length = 0;
     }
     n++  ;

     FloatToStr(sinyal[i],text);
     mikrobus_logWrite(text, _LOG_LINE);
//      Delay_Us(4000);
}
void Timer7_interrupt() iv IVT_INT_TIM7 {
  TIM7_SR.UIF = 0;

  Check_TP();
  if (buttonFlag){
     ApplicationTaskECG();
  }

}
void ButtonRound2OnClick() {
float rmssd1 = 0;
float rmssd[400];
float result_rmssd;
   // NILAI RMSSD
for (i = 0; i < b_length - 1; i++) {
         rmssd[i] = fabs(nilairr[i-1] - nilairr[i]);
     }

     for(i = 0; i < b_length - 1; i++) {
         rmssd1 += rmssd[i] * rmssd[i];
     }
     result_rmssd = sqrt(rmssd1 / (float)(b_length - 1));

//   for (i=1; i<= b_lenght; i++){
//       rmssd += ((nilairr[i+1] - nilairr[i]) * (nilairr[i+1] - nilairr[i]));
//   }
//   result_rmssd = sqrt(rmssd/(b_lenght - 1));

   TFT_Set_Pen(CL_BLACK, 1);
   TFT_Set_Brush(1, 0,0, LEFT_TO_RIGHT, CL_BLACK, CL_BLACK);
   TFT_Rectangle(645, 390, 645+140, 390+100);
   TFT_Set_Pen(CL_YELLOW, 5);
   TFT_Set_Font(Tahoma32x33_Bold, CL_WHITE, FO_HORIZONTAL);
   FloatToStr(result_rmssd, text );
   TFT_Write_Text(text, 645, 390);
}
