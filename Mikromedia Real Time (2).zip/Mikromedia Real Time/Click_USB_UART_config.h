#include "Click_USB_UART_types.h"

const uint32_t _USB_UART_UART_CFG[ 4 ] =
{
        9600, 
        _UART_8_BIT_DATA, 
    _UART_NOPARITY, 
    _UART_ONE_STOPBIT
}  ;