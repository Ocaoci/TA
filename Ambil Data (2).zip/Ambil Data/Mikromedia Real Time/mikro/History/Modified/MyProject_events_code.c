#include "MyProject_objects.h"
#include "MyProject_resources.h"
#include "variabel.h"
#include "dwt.h"

//--------------------- User code ---------------------//
void bingkai(int X1, int Y1, int X2, int Y2, float dat)
{
    TFT_Set_Pen(CL_WHITE, 1);
    TFT_Set_Brush(0, 0, 0, LEFT_TO_RIGHT, CL_WHITE, CL_WHITE);
    TFT_Rectangle(X1, Y1, X2, Y2);
    TFT_Set_Font(Tahoma11x13_Regular, CL_BLACK, FO_HORIZONTAL);
    FloatToStr(dat, text);
    TFT_Write_Text(text, X1, Y1);
    Delay_ms(10);
}
//----------------- End of User code ------------------//

// Event Handlers
void ButtonRound1OnClick() {
//  DrawScreen(&Screen2);
  int i, j, x, y ;
  dwtout();
  x = 20;
  y = 95;
  TFT_Set_Pen(CL_WHITE, 2);
  TFT_Set_Brush(0, 0, 0, LEFT_TO_RIGHT, CL_WHITE, CL_WHITE);
  TFT_Rectangle(x, y, x + 760, y + 290);
  for (i = 0; i <= 760; i++) {
       TFT_Set_Pen(CL_BLACK, 2);
        TFT_Line(20+(i-1), 130+70*sinyal[i-1]*(-1), 20+i, 130+70*sinyal[i]*(-1));
       //TFT_H_Line(20, 780, 130);
       TFT_Set_Pen(CL_RED, 2);
       TFT_Line(20+(i-1), 250+100*w2fb3[i-1], 20+i, 250+100*w2fb3[i]);
       Delay_ms(10);
   //}
   bingkai(75, 100, 100, 200, w2fb3[0]);
   bingkai(75, 120, 100, 200, qj3[0]);
   }
}

void Button1OnClick() {

}