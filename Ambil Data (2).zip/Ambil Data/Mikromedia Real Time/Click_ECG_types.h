#ifndef _ECG_T_
#define _ECG_T_

#include "stdint.h"

#ifndef _ECG_H_

#define T_ECG_P const uint8_t* 

#endif
#endif