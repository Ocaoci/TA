    int dirac(int x) {
    int diracdelta;
    if (x == 0) {
        diracdelta = 1;
    } else {
        diracdelta = 0;
    }
    return diracdelta;
}

void dwtout(){
    int i, j, k;
    float w2fb1[1250], w2fb2[1252], w2fb3[1254];
    float gradien1[1250], gradien2[1252], gradien3[1254];
    float  hasil1[1250], hasil2[1250], hasil3[1250], temp[1250];
    for (j = 1; j<=3; j++){
        for (i = -(dua_pangkat[j]+dua_pangkat[j-1]-2); i <= -(1-dua_pangkat[j-1]); i++){
            if (j == 1){
                qj1[i+1] = -2*(float)(dirac(i)-dirac(i+1));
            }  else if (j==2){
                qj2[i+4] = -1.0/4.0*(float)(dirac(i-1) + 3*dirac(i) + 2*dirac(i+1) - 2*dirac(i+2)- 3*dirac(i+3) - dirac(i+4));
            }   else if (j==3){
                qj3[i+10] = -1.0/32.0*(float)(dirac(i-3) + 3*dirac(i-2) + 6*dirac(i-1) + 10*dirac(i) + 11*dirac(i+1) + 9*dirac(i+2) + 4*dirac(i+3) - 4*dirac(i+4) - 9*dirac(i+5) - 11*dirac(i+6) - 10*dirac(i+7) - 6*dirac(i+8) - 3*dirac(i+9) - dirac(i+10));
            }
        }

    }
     for (i = 0; i <= 1250; i++){
         w2fb1[i + delay[1]] = 0;
         w2fb2[i + delay[2]] = 0;
         w2fb3[i + delay[3]] = 0;
         for (j = 1; j <= 3; j++){
             for (k = -(dua_pangkat[j]+dua_pangkat[j-1] - 2); k <= -(1-dua_pangkat[j-1]); k++){
                 if (j == 1){
                    w2fb1[i + delay[1]] += qj1[k+1] * sinyal[i-k];
                 } else if (j == 2){
                   w2fb2[i + delay[2]] += qj2[k+4] * sinyal[i-k];
                 } else if (j == 3){
                   w2fb3[i + delay[3]] += qj3[k+10] * sinyal[i-k];
                 }
             }
         }
         gradien1[i] = w2fb1[i+1] - w2fb1[i];
        gradien2[i] = w2fb2[i+2] - w2fb2[i];
        gradien3[i] = w2fb3[i+3] - w2fb3[i];
        if (gradien1[i] > 0.0 && gradien2[i] > 0.0 && gradien3[i] > 0.0){
           hasil_QRS[i] = 1;
        } else {
          hasil_QRS[i] = 0;
        }
    }

   //  for (i = 0; i <= 1250; i++);{

      //  if(gradien1[n] > 0.3) {
      //       hasil1[n] = 1;
      //  }
      //  else {
      //      hasil1[n] = 0;
      //  }

      //  if(gradien2[n] > 1) {
      //      hasil2[n] = 1;
      //  }
      //  else {
      //      hasil2[n] = 0;
      //  }
      //  if(gradien3[n] > 2) {
      //      hasil3[n] = 1;
      //   }
      //  else {
      //       hasil3[n] = 0;
      //  }
      //  if (hasil1[n] == hasil2[n]){
      //  temp[n]=1;
      //  }
      //  else{temp[n] = 0;}
      //  if (temp[n] == hasil3[n]){
      //  hasil_QRS[n]=1;
      //  }
      //  else{hasil_QRS[n] = 0;}
    // }
}
